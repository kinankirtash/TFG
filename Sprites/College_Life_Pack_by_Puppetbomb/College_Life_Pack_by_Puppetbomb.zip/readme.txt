------------------------------------------------------------

      !! DO NOT DISTRIBUTE PACK WITHOUT README.TXT !!

------------------------------------------------------------

                    College Life Bundle
                       by puppetbomb

Originally distributed through Lemma Soft Forums 
(https://lemmasoft.renai.us/) by puppetbomb.

Assets may not be used for commercial purposes under 
the Attribution-NonCommercial 3.0 Unported (CC BY-NC 3.0)
(https://creativecommons.org/licenses/by-nc/4.0/)

E-mail : puppetbomb@gmail.com